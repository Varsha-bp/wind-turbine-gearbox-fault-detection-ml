"""
src/models.py
--------------
Train, evaluate, compare, and save ML models for gearbox fault detection.
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
import joblib
import json

from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    ConfusionMatrixDisplay,
)
from sklearn.model_selection import GridSearchCV, cross_val_score

try:
    from xgboost import XGBClassifier
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False
    print("[models] XGBoost not installed – skipping.")

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
MODELS_DIR = "models"
REPORTS_DIR = os.path.join(MODELS_DIR, "reports")
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(REPORTS_DIR, exist_ok=True)

CLASS_NAMES = {
    0: "Healthy",
    1: "Inner_Race",
    2: "Outer_Race",
    3: "Ball_Fault",
    4: "Gear_Wear",
}


# ---------------------------------------------------------------------------
# 1. Model definitions
# ---------------------------------------------------------------------------

def get_random_forest(tuned: bool = True):
    """Random Forest with optional hyperparameter tuning grid."""
    if tuned:
        param_grid = {
            "n_estimators": [200, 300],
            "max_depth": [None, 20],
            "min_samples_split": [2, 5],
        }
        base = RandomForestClassifier(random_state=42, n_jobs=-1)
        return GridSearchCV(base, param_grid, cv=3, scoring="accuracy", n_jobs=-1, verbose=1)
    return RandomForestClassifier(n_estimators=300, max_depth=None, random_state=42, n_jobs=-1)


def get_svm(tuned: bool = True):
    """SVM with RBF kernel."""
    if tuned:
        param_grid = {
            "C": [1, 10, 100],
            "gamma": ["scale", "auto"],
        }
        base = SVC(kernel="rbf", probability=True, random_state=42)
        return GridSearchCV(base, param_grid, cv=3, scoring="accuracy", n_jobs=-1, verbose=1)
    return SVC(kernel="rbf", C=10, gamma="scale", probability=True, random_state=42)


def get_xgboost(tuned: bool = False):
    """XGBoost – lightweight settings for 8GB RAM."""
    if not XGBOOST_AVAILABLE:
        return None
    return XGBClassifier(
        n_estimators=300,
        max_depth=6,
        learning_rate=0.1,
        subsample=0.8,
        colsample_bytree=0.8,
        use_label_encoder=False,
        eval_metric="mlogloss",
        random_state=42,
        n_jobs=-1,
    )


# ---------------------------------------------------------------------------
# 2. Train a single model
# ---------------------------------------------------------------------------

def train_model(model, X_train, y_train, model_name="model"):
    """Fit model and return it."""
    print(f"\n{'='*55}")
    print(f" Training: {model_name}")
    print(f"{'='*55}")
    model.fit(X_train, y_train)

    # If GridSearchCV, show best params
    if hasattr(model, "best_params_"):
        print(f" Best params: {model.best_params_}")
        print(f" Best CV accuracy: {model.best_score_:.4f}")

    return model


# ---------------------------------------------------------------------------
# 3. Evaluate a single model
# ---------------------------------------------------------------------------

def evaluate_model(model, X_test, y_test, model_name="model", feature_names=None):
    """
    Evaluate model and generate:
    - Accuracy score
    - Classification report
    - Confusion matrix (saved as PNG)
    """
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    report = classification_report(
        y_test, y_pred,
        target_names=list(CLASS_NAMES.values()),
        output_dict=False
    )
    report_dict = classification_report(
        y_test, y_pred,
        target_names=list(CLASS_NAMES.values()),
        output_dict=True
    )

    print(f"\n[{model_name}] Accuracy: {acc:.4f} ({acc*100:.2f}%)")
    print(report)

    # Confusion matrix
    cm = confusion_matrix(y_test, y_pred)
    fig, ax = plt.subplots(figsize=(8, 6))
    disp = ConfusionMatrixDisplay(
        confusion_matrix=cm,
        display_labels=list(CLASS_NAMES.values())
    )
    disp.plot(ax=ax, cmap="Blues", colorbar=False)
    ax.set_title(f"Confusion Matrix – {model_name}\nAccuracy: {acc*100:.2f}%")
    plt.tight_layout()
    cm_path = os.path.join(REPORTS_DIR, f"cm_{model_name.lower().replace(' ', '_')}.png")
    plt.savefig(cm_path, dpi=120)
    plt.close()
    print(f" Confusion matrix saved to: {cm_path}")

    # Feature importance (RF / XGB only)
    if feature_names is not None:
        _plot_feature_importance(model, feature_names, model_name)

    return {
        "model_name": model_name,
        "accuracy": acc,
        "report": report_dict,
        "cm_path": cm_path,
    }


def _plot_feature_importance(model, feature_names, model_name):
    """Plot top-20 feature importances for tree-based models."""
    estimator = model.best_estimator_ if hasattr(model, "best_estimator_") else model
    if not hasattr(estimator, "feature_importances_"):
        return
    importances = estimator.feature_importances_
    idx = np.argsort(importances)[-20:][::-1]
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.barh(
        [feature_names[i] for i in idx][::-1],
        importances[idx][::-1],
        color="steelblue"
    )
    ax.set_xlabel("Importance")
    ax.set_title(f"Top-20 Feature Importances – {model_name}")
    plt.tight_layout()
    fi_path = os.path.join(REPORTS_DIR, f"fi_{model_name.lower().replace(' ', '_')}.png")
    plt.savefig(fi_path, dpi=120)
    plt.close()
    print(f" Feature importance saved to: {fi_path}")


# ---------------------------------------------------------------------------
# 4. Compare all models
# ---------------------------------------------------------------------------

def compare_models(results: list):
    """Bar chart comparing model accuracies."""
    names = [r["model_name"] for r in results]
    accs = [r["accuracy"] for r in results]

    colors = ["#2196F3", "#4CAF50", "#FF9800"]
    fig, ax = plt.subplots(figsize=(8, 5))
    bars = ax.bar(names, [a * 100 for a in accs], color=colors[: len(names)], edgecolor="black")
    ax.set_ylabel("Accuracy (%)")
    ax.set_title("Model Comparison – Gearbox Fault Detection")
    ax.set_ylim(0, 105)
    ax.axhline(y=90, color="red", linestyle="--", linewidth=1.5, label="90% target")
    for bar, acc in zip(bars, accs):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.5,
            f"{acc*100:.2f}%",
            ha="center", va="bottom", fontweight="bold"
        )
    ax.legend()
    plt.tight_layout()
    comp_path = os.path.join(REPORTS_DIR, "model_comparison.png")
    plt.savefig(comp_path, dpi=120)
    plt.close()
    print(f"\nModel comparison chart saved to: {comp_path}")

    # Print ranking
    results_sorted = sorted(results, key=lambda x: x["accuracy"], reverse=True)
    print("\n Model Ranking:")
    for i, r in enumerate(results_sorted, 1):
        print(f"  {i}. {r['model_name']}: {r['accuracy']*100:.2f}%")
    return results_sorted


# ---------------------------------------------------------------------------
# 5. Save best model
# ---------------------------------------------------------------------------

def save_best_model(model, model_name: str, feature_names: list, class_names: dict):
    """Serialize best model + metadata."""
    # Unwrap GridSearchCV
    estimator = model.best_estimator_ if hasattr(model, "best_estimator_") else model
    path = os.path.join(MODELS_DIR, "best_model.pkl")
    joblib.dump(estimator, path)

    meta = {
        "model_name": model_name,
        "feature_names": feature_names,
        "class_names": class_names,
        "n_features": len(feature_names),
    }
    meta_path = os.path.join(MODELS_DIR, "model_metadata.json")
    with open(meta_path, "w") as f:
        json.dump(meta, f, indent=2)

    print(f"\nBest model saved to   : {path}")
    print(f"Model metadata saved  : {meta_path}")


def load_best_model():
    """Load best model and its metadata."""
    model = joblib.load(os.path.join(MODELS_DIR, "best_model.pkl"))
    with open(os.path.join(MODELS_DIR, "model_metadata.json")) as f:
        meta = json.load(f)
    return model, meta
