"""
src/preprocessing.py
---------------------
Data loading, cleaning, feature engineering, and scaling pipeline.
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import joblib
import os


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
FEATURE_COLS = None          # set dynamically after loading
TARGET_COL = "label"
CONDITION_COL = "condition"
SCALER_PATH = os.path.join("models", "scaler.pkl")


# ---------------------------------------------------------------------------
# 1. Load data
# ---------------------------------------------------------------------------

def load_data(path: str) -> pd.DataFrame:
    """Load CSV, basic integrity checks."""
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Dataset not found at '{path}'. "
            "Run: python data/generate_dataset.py"
        )
    df = pd.read_csv(path)
    print(f"[load_data] Loaded {df.shape[0]} rows × {df.shape[1]} columns")
    return df


# ---------------------------------------------------------------------------
# 2. Handle missing values
# ---------------------------------------------------------------------------

def handle_missing(df: pd.DataFrame) -> pd.DataFrame:
    """
    Strategy:
    - For numeric columns: fill NaN with column median (robust to outliers).
    - Drop rows where target is missing.
    """
    before = df.isnull().sum().sum()
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    df[numeric_cols] = df[numeric_cols].fillna(df[numeric_cols].median())
    df = df.dropna(subset=[TARGET_COL])
    after = df.isnull().sum().sum()
    print(f"[handle_missing] Missing values: before={before}, after={after}")
    return df.reset_index(drop=True)


# ---------------------------------------------------------------------------
# 3. Remove outliers (optional, gentle IQR clipping)
# ---------------------------------------------------------------------------

def clip_outliers(df: pd.DataFrame, feature_cols: list, factor: float = 5.0) -> pd.DataFrame:
    """
    Clip extreme outliers using IQR method.
    factor=5.0 is conservative (keeps most real fault signals).
    """
    df = df.copy()
    for col in feature_cols:
        q1 = df[col].quantile(0.01)
        q3 = df[col].quantile(0.99)
        iqr = q3 - q1
        lower = q1 - factor * iqr
        upper = q3 + factor * iqr
        df[col] = df[col].clip(lower=lower, upper=upper)
    print(f"[clip_outliers] Clipped {len(feature_cols)} feature columns (factor={factor})")
    return df


# ---------------------------------------------------------------------------
# 4. Feature engineering (additional ratio features)
# ---------------------------------------------------------------------------

def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """Add a few engineered features that improve fault discrimination."""
    df = df.copy()

    # Crest factor × kurtosis interaction (very sensitive to impulse faults)
    if "crest_factor" in df.columns and "kurtosis" in df.columns:
        df["crest_kurtosis"] = df["crest_factor"] * df["kurtosis"]

    # RMS / spectral centroid ratio (changes under gear wear)
    if "rms" in df.columns and "spectral_centroid" in df.columns:
        df["rms_centroid_ratio"] = df["rms"] / (df["spectral_centroid"] + 1e-10)

    # High-frequency energy × kurtosis (fault indicator)
    if "hf_energy_ratio" in df.columns and "kurtosis" in df.columns:
        df["hf_kurtosis"] = df["hf_energy_ratio"] * df["kurtosis"]

    print(f"[engineer_features] DataFrame shape after engineering: {df.shape}")
    return df


# ---------------------------------------------------------------------------
# 5. Scaling
# ---------------------------------------------------------------------------

def scale_features(
    X_train: np.ndarray,
    X_test: np.ndarray,
    save: bool = True,
) -> tuple:
    """Fit StandardScaler on train, transform both splits."""
    scaler = StandardScaler()
    X_train_sc = scaler.fit_transform(X_train)
    X_test_sc = scaler.transform(X_test)
    if save:
        os.makedirs("models", exist_ok=True)
        joblib.dump(scaler, SCALER_PATH)
        print(f"[scale_features] Scaler saved to {SCALER_PATH}")
    return X_train_sc, X_test_sc, scaler


def load_scaler():
    """Load pre-fitted scaler from disk."""
    return joblib.load(SCALER_PATH)


# ---------------------------------------------------------------------------
# 6. Full pipeline
# ---------------------------------------------------------------------------

def full_pipeline(data_path: str, test_size: float = 0.2, random_state: int = 42):
    """
    End-to-end preprocessing.
    Returns: X_train, X_test, y_train, y_test, feature_names, scaler
    """
    # Load
    df = load_data(data_path)

    # Handle missing
    df = handle_missing(df)

    # Determine feature columns (everything except label/condition/string cols)
    non_feature = [TARGET_COL, CONDITION_COL]
    feature_cols = [
        c for c in df.columns
        if c not in non_feature and df[c].dtype in [np.float64, np.int64, np.float32]
    ]

    # Clip outliers
    df = clip_outliers(df, feature_cols)

    # Engineer features
    df = engineer_features(df)

    # Re-derive feature columns after engineering
    feature_cols = [
        c for c in df.columns
        if c not in non_feature and df[c].dtype in [np.float64, np.int64, np.float32]
    ]

    X = df[feature_cols].values
    y = df[TARGET_COL].values

    print(f"[full_pipeline] Features: {len(feature_cols)} | Samples: {len(y)}")
    print(f"[full_pipeline] Class distribution: {dict(zip(*np.unique(y, return_counts=True)))}")

    # Train/test split (stratified)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )

    # Scale
    X_train_sc, X_test_sc, scaler = scale_features(X_train, X_test)

    print(f"[full_pipeline] Train: {X_train_sc.shape} | Test: {X_test_sc.shape}")
    return X_train_sc, X_test_sc, y_train, y_test, feature_cols, scaler


if __name__ == "__main__":
    X_train, X_test, y_train, y_test, feats, scaler = full_pipeline(
        "data/gearbox_vibration_data.csv"
    )
    print("Preprocessing complete.")
