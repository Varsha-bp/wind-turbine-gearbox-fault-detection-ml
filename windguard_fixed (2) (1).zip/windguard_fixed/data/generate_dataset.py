"""
generate_dataset.py
-------------------
Generates a synthetic but realistic gearbox vibration dataset.
This mimics real-world CWRU / PRONOSTIA-style data.

Run: python data/generate_dataset.py
Output: data/gearbox_vibration_data.csv
"""

import numpy as np
import pandas as pd
from scipy import signal
import os

np.random.seed(42)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
SAMPLING_RATE = 12000       # Hz (same as CWRU bearing dataset)
SEGMENT_DURATION = 0.1      # seconds per sample window
N_SAMPLES_PER_CLASS = 2000  # samples per condition
SEGMENT_LENGTH = int(SAMPLING_RATE * SEGMENT_DURATION)  # 1200 points

FAULT_CLASSES = {
    0: "Healthy",
    1: "Inner_Race_Fault",
    2: "Outer_Race_Fault",
    3: "Ball_Fault",
    4: "Gear_Wear",
}

# ---------------------------------------------------------------------------
# Signal generation helpers
# ---------------------------------------------------------------------------

def generate_healthy_signal(length, fs=12000):
    """Normal operation: low-level broadband noise + shaft harmonics."""
    t = np.linspace(0, length / fs, length)
    shaft_freq = 29.95  # ~30 Hz shaft rotation
    sig = (
        0.1 * np.sin(2 * np.pi * shaft_freq * t)
        + 0.05 * np.sin(2 * np.pi * 2 * shaft_freq * t)
        + 0.02 * np.sin(2 * np.pi * 3 * shaft_freq * t)
        + np.random.normal(0, 0.05, length)
    )
    return sig


def generate_inner_race_fault(length, fs=12000):
    """Inner race fault: periodic impulses at BPFI."""
    t = np.linspace(0, length / fs, length)
    shaft_freq = 29.95
    bpfi = 162.2  # Ball Pass Frequency Inner race (Hz)
    sig = generate_healthy_signal(length, fs)
    # Add modulated impulse train
    impulse_times = np.arange(0, length / fs, 1 / bpfi)
    for ti in impulse_times:
        idx = int(ti * fs)
        if idx < length:
            window = signal.windows.gaussian(min(50, length - idx), std=3)
            sig[idx: idx + len(window)] += 0.8 * window * (1 + 0.3 * np.sin(2 * np.pi * shaft_freq * ti))
    sig += np.random.normal(0, 0.08, length)
    return sig


def generate_outer_race_fault(length, fs=12000):
    """Outer race fault: periodic impulses at BPFO."""
    t = np.linspace(0, length / fs, length)
    bpfo = 107.4  # Ball Pass Frequency Outer race (Hz)
    sig = generate_healthy_signal(length, fs)
    impulse_times = np.arange(0, length / fs, 1 / bpfo)
    for ti in impulse_times:
        idx = int(ti * fs)
        if idx < length:
            window = signal.windows.gaussian(min(40, length - idx), std=3)
            sig[idx: idx + len(window)] += 0.7 * window
    sig += np.random.normal(0, 0.07, length)
    return sig


def generate_ball_fault(length, fs=12000):
    """Ball fault: impulses at BSF (Ball Spin Frequency)."""
    t = np.linspace(0, length / fs, length)
    shaft_freq = 29.95
    bsf = 141.2  # Ball Spin Frequency (Hz)
    sig = generate_healthy_signal(length, fs)
    impulse_times = np.arange(0, length / fs, 1 / bsf)
    for ti in impulse_times:
        idx = int(ti * fs)
        if idx < length:
            window = signal.windows.gaussian(min(30, length - idx), std=2)
            sig[idx: idx + len(window)] += 0.5 * window * (1 + 0.2 * np.sin(2 * np.pi * 2 * shaft_freq * ti))
    sig += np.random.normal(0, 0.06, length)
    return sig


def generate_gear_wear(length, fs=12000):
    """Gear wear: elevated broadband noise + increased harmonic amplitudes."""
    t = np.linspace(0, length / fs, length)
    shaft_freq = 29.95
    gear_mesh_freq = shaft_freq * 43  # 43 teeth
    sig = (
        0.3 * np.sin(2 * np.pi * shaft_freq * t)
        + 0.15 * np.sin(2 * np.pi * 2 * shaft_freq * t)
        + 0.4 * np.sin(2 * np.pi * gear_mesh_freq * t)
        + 0.2 * np.sin(2 * np.pi * 2 * gear_mesh_freq * t)
        + np.random.normal(0, 0.15, length)
    )
    return sig


GENERATORS = {
    0: generate_healthy_signal,
    1: generate_inner_race_fault,
    2: generate_outer_race_fault,
    3: generate_ball_fault,
    4: generate_gear_wear,
}


# ---------------------------------------------------------------------------
# Feature extraction (time + frequency domain)
# ---------------------------------------------------------------------------

def extract_features(sig, fs=12000):
    """Extract 26 statistical and spectral features from a signal segment."""
    features = {}

    # --- Time domain ---
    features["mean"] = np.mean(sig)
    features["std"] = np.std(sig)
    features["rms"] = np.sqrt(np.mean(sig ** 2))
    features["peak"] = np.max(np.abs(sig))
    features["peak_to_peak"] = np.max(sig) - np.min(sig)
    features["crest_factor"] = features["peak"] / (features["rms"] + 1e-10)
    features["kurtosis"] = pd.Series(sig).kurt()
    features["skewness"] = pd.Series(sig).skew()
    features["shape_factor"] = features["rms"] / (np.mean(np.abs(sig)) + 1e-10)
    features["impulse_factor"] = features["peak"] / (np.mean(np.abs(sig)) + 1e-10)
    features["margin_factor"] = features["peak"] / (np.mean(np.sqrt(np.abs(sig))) ** 2 + 1e-10)
    features["energy"] = np.sum(sig ** 2)
    features["variance"] = np.var(sig)
    features["zero_crossing_rate"] = ((sig[:-1] * sig[1:]) < 0).sum() / len(sig)

    # --- Frequency domain (FFT) ---
    N = len(sig)
    fft_vals = np.abs(np.fft.rfft(sig))
    freqs = np.fft.rfftfreq(N, d=1 / fs)

    # Spectral centroid
    features["spectral_centroid"] = np.sum(freqs * fft_vals) / (np.sum(fft_vals) + 1e-10)
    # Spectral spread
    features["spectral_spread"] = np.sqrt(
        np.sum(((freqs - features["spectral_centroid"]) ** 2) * fft_vals) / (np.sum(fft_vals) + 1e-10)
    )
    # Spectral entropy
    psd = fft_vals ** 2
    psd_norm = psd / (psd.sum() + 1e-10)
    features["spectral_entropy"] = -np.sum(psd_norm * np.log(psd_norm + 1e-10))
    # Spectral kurtosis
    features["spectral_kurtosis"] = pd.Series(fft_vals).kurt()
    # Band energy ratios (divide spectrum into 4 bands)
    band_edges = [0, 500, 2000, 5000, 6000]
    for i in range(len(band_edges) - 1):
        mask = (freqs >= band_edges[i]) & (freqs < band_edges[i + 1])
        features[f"band_energy_{i+1}"] = np.sum(fft_vals[mask] ** 2)

    # --- Wavelet-like: high-frequency ratio ---
    hf_mask = freqs > 3000
    features["hf_energy_ratio"] = np.sum(fft_vals[hf_mask] ** 2) / (np.sum(fft_vals ** 2) + 1e-10)

    # 5 highest FFT magnitude peaks (indicative of fault frequencies)
    top_idx = np.argsort(fft_vals)[-5:][::-1]
    for j, idx in enumerate(top_idx):
        features[f"top_freq_{j+1}"] = freqs[idx]
        features[f"top_mag_{j+1}"] = fft_vals[idx]

    return features


# ---------------------------------------------------------------------------
# Main dataset generation
# ---------------------------------------------------------------------------

def build_dataset():
    rows = []
    for label, name in FAULT_CLASSES.items():
        print(f"  Generating class {label}: {name} ...")
        gen_fn = GENERATORS[label]
        for _ in range(N_SAMPLES_PER_CLASS):
            raw_sig = gen_fn(SEGMENT_LENGTH)
            feats = extract_features(raw_sig)
            feats["label"] = label
            feats["condition"] = name
            rows.append(feats)

    df = pd.DataFrame(rows)
    return df


if __name__ == "__main__":
    os.makedirs("data", exist_ok=True)
    print("Generating gearbox vibration dataset...")
    df = build_dataset()
    out_path = os.path.join("data", "gearbox_vibration_data.csv")
    df.to_csv(out_path, index=False)
    print(f"\nDataset saved to: {out_path}")
    print(f"Shape          : {df.shape}")
    print(f"Class dist.    :\n{df['condition'].value_counts()}")
    print(f"\nFeature columns: {[c for c in df.columns if c not in ['label','condition']]}")
EOF