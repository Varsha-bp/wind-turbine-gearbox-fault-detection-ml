/**
 * WindGuard AI — Base JavaScript
 * Handles: SocketIO connection, theme, clock, toast notifications
 */

// ─── Global SocketIO Connection ───────────────────────────────────────────
const socket = io({ transports: ['websocket', 'polling'] });
let currentTurbineId = 'WT-001';

socket.on('connect', () => {
  updateConnStatus('connected', 'WebSocket Live');
  console.log('[WG] Socket connected:', socket.id);
});

socket.on('disconnect', () => {
  updateConnStatus('error', 'Disconnected');
});

socket.on('connect_error', () => {
  updateConnStatus('error', 'Connection failed');
});

function updateConnStatus(state, text) {
  const el = document.getElementById('conn-indicator');
  const tx = document.getElementById('conn-text');
  if (!el || !tx) return;
  el.className = 'wg-conn-indicator ' + state;
  tx.textContent = text;
}

// ─── Initial state from socket ────────────────────────────────────────────
socket.on('initial_state', (data) => {
  if (data.fault_count !== undefined) updateFaultBadge(data.fault_count);
});

socket.on('sensor_update', (data) => {
  // Update sidebar footer with fault count
  const faults = data.readings.filter(r => r.state === 'fault').length;
  updateFaultBadge(faults);
});

function updateFaultBadge(count) {
  const badge = document.getElementById('fault-badge');
  if (badge) badge.textContent = count;
  const sbFaults = document.getElementById('sb-faults');
  if (sbFaults) sbFaults.textContent = count;
}

// ─── Live Clock ───────────────────────────────────────────────────────────
function updateClock() {
  const el = document.getElementById('live-clock');
  if (!el) return;
  const now = new Date();
  el.textContent = now.toLocaleTimeString('en-US', { hour12: false });
}
setInterval(updateClock, 1000);
updateClock();

// ─── Dark/Light Mode Toggle ───────────────────────────────────────────────
const themeToggle = document.getElementById('themeToggle');
const themeIcon   = document.getElementById('themeIcon');

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('wg-theme', theme);
  if (themeIcon) {
    themeIcon.className = theme === 'dark' ? 'fa-solid fa-moon' : 'fa-solid fa-sun';
  }
}

// Load saved theme
const savedTheme = localStorage.getItem('wg-theme') || 'dark';
applyTheme(savedTheme);

if (themeToggle) {
  themeToggle.addEventListener('click', () => {
    const current = document.documentElement.getAttribute('data-theme');
    applyTheme(current === 'dark' ? 'light' : 'dark');
  });
}

// ─── Mobile Sidebar Toggle ────────────────────────────────────────────────
const mobToggle = document.getElementById('mobToggle');
const sidebar   = document.getElementById('sidebar');

if (mobToggle) {
  mobToggle.addEventListener('click', () => {
    sidebar.classList.toggle('open');
  });
  // Close sidebar on outside click
  document.addEventListener('click', (e) => {
    if (!sidebar.contains(e.target) && !mobToggle.contains(e.target)) {
      sidebar.classList.remove('open');
    }
  });
}

// ─── Toast Notifications ──────────────────────────────────────────────────
/**
 * Show a toast notification
 * @param {string} message - Main message text
 * @param {string} type - 'fault' | 'warning' | 'success' | 'info'
 * @param {string} title - Optional title text
 */
function showToast(message, type = 'info', title = '') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const icons = {
    fault:   'fa-circle-xmark',
    warning: 'fa-triangle-exclamation',
    success: 'fa-circle-check',
    info:    'fa-circle-info',
  };

  const icon = icons[type] || icons.info;
  const toast = document.createElement('div');
  toast.className = `wg-toast ${type}`;
  toast.innerHTML = `
    <i class="fa-solid ${icon}" style="flex-shrink:0"></i>
    <div>
      ${title ? `<div style="font-weight:700;font-size:11px;font-family:var(--font-mono);margin-bottom:2px">${title}</div>` : ''}
      <div>${message}</div>
    </div>
    <i class="fa-solid fa-xmark ms-auto" style="opacity:0.5;flex-shrink:0"></i>
  `;

  toast.addEventListener('click', () => toast.remove());
  container.appendChild(toast);

  // Auto-remove after 5 seconds
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(20px)';
    toast.style.transition = 'all 0.3s';
    setTimeout(() => toast.remove(), 300);
  }, 5000);
}

// ─── Show/dismiss alert banner ────────────────────────────────────────────
function showAlertBanner(msg) {
  const banner = document.getElementById('alert-banner');
  const text   = document.getElementById('alert-banner-text');
  if (banner && text) {
    text.textContent = msg;
    banner.classList.remove('d-none');
  }
}

// ─── Turbine selection (used on multiple pages) ────────────────────────────
function selectTurbine(tid) {
  currentTurbineId = tid;
  // Highlight selected turbine card
  document.querySelectorAll('.wg-turb-card').forEach(c => c.classList.remove('selected'));
  const card = document.querySelector(`.wg-turb-card[data-id="${tid}"]`);
  if (card) card.classList.add('selected');
}

// ─── Chart.js Default Theme ───────────────────────────────────────────────
Chart.defaults.color          = '#7c9ab8';
Chart.defaults.borderColor    = '#1a2d48';
Chart.defaults.backgroundColor = 'rgba(0,217,245,0.1)';
Chart.defaults.font.family    = "'JetBrains Mono', monospace";
Chart.defaults.font.size      = 11;

/**
 * Create a line chart with WindGuard styling
 */
function createLineChart(canvasId, label, color, maxPoints = 50) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return null;

  return new Chart(ctx, {
    type: 'line',
    data: {
      labels: [],
      datasets: [{
        label,
        data: [],
        borderColor: color,
        backgroundColor: hexToRgba(color, 0.08),
        borderWidth: 1.5,
        fill: true,
        tension: 0.4,
        pointRadius: 0,
        pointHoverRadius: 4,
      }]
    },
    options: {
      animation: { duration: 200 },
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: ctx => ` ${ctx.parsed.y.toFixed(4)}`
          }
        }
      },
      scales: {
        x: {
          grid: { color: 'rgba(26,45,72,0.6)' },
          ticks: { maxTicksLimit: 6 }
        },
        y: {
          grid: { color: 'rgba(26,45,72,0.6)' },
          ticks: { maxTicksLimit: 5 }
        }
      }
    }
  });
}

/**
 * Push a new data point to a line chart (maintains max buffer)
 */
function pushChartData(chart, label, value, maxPoints = 50) {
  if (!chart) return;
  chart.data.labels.push(label);
  chart.data.datasets[0].data.push(value);
  if (chart.data.labels.length > maxPoints) {
    chart.data.labels.shift();
    chart.data.datasets[0].data.shift();
  }
  chart.update('none');
}

function hexToRgba(hex, alpha) {
  const r = parseInt(hex.slice(1,3),16);
  const g = parseInt(hex.slice(3,5),16);
  const b = parseInt(hex.slice(5,7),16);
  return `rgba(${r},${g},${b},${alpha})`;
}

// ─── Fetch API wrapper ────────────────────────────────────────────────────
async function apiGet(endpoint) {
  try {
    const r = await fetch(endpoint);
    if (!r.ok) throw new Error(r.statusText);
    return await r.json();
  } catch (e) {
    console.error('[WG API]', endpoint, e);
    return null;
  }
}

async function apiPost(endpoint, body) {
  try {
    const r = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    if (!r.ok) throw new Error(r.statusText);
    return await r.json();
  } catch (e) {
    console.error('[WG API POST]', endpoint, e);
    return null;
  }
}
