/* WindGuard AI — Fixed Prediction JS
   Fixes:
   - Correct input source badge (Manual Input / CSV Input / Drone Image / Demo Signal)
   - RMS Trend chart added
   - Drone result fully populated
   - Error messages shown cleanly
   - Loading state properly reset
*/

let currentMode = 'demo';
let currentDemo = 'Healthy';
let csvFile = null;
let droneFile = null;
let turbineName = '';
let probaChart, radarChart, waveformChart, fftChart, rmsTrendChart;

function updateTurbineName(val) { turbineName = val.trim(); }

const SOURCE_LABELS = {
  demo:   '🔬 Demo Signal',
  manual: '🎛️ Manual Input',
  csv:    '📄 CSV Input',
  drone:  '📡 Drone Image',
};

function switchMode(mode) {
  currentMode = mode;
  ['demo','manual','csv','drone'].forEach(m => {
    document.getElementById('panel-'+m).classList.toggle('d-none', m !== mode);
    document.querySelector(`[data-mode="${m}"]`).classList.toggle('active', m === mode);
  });
  if (mode !== 'drone') document.getElementById('drone-result-box').classList.add('d-none');
  // Update active source label
  const lbl = document.getElementById('active-source-label');
  if (lbl) lbl.textContent = SOURCE_LABELS[mode] || mode;
}

function selectDemo(el, mode) {
  document.querySelectorAll('.wg-demo-opt').forEach(o => o.classList.remove('selected'));
  el.classList.add('selected');
  currentDemo = mode;
}

function getTurbineName() {
  const n = document.getElementById('turbine-name-input').value.trim();
  if (!n) { showPredictionError('Please enter a turbine name before running analysis.'); return null; }
  return n;
}

async function runDemoPrediction() {
  const name = getTurbineName(); if (!name) return;
  setLoading(true);
  try {
    const res = await fetch('/api/predict/demo', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({mode: currentDemo, turbine_name: name})
    });
    const data = await res.json();
    if (data.error) { showPredictionError(data.error); return; }
    renderResult(data, 'Demo Signal');
    showToast(`${name} analyzed — ${data.condition}`, data.is_fault ? 'fault' : 'ok');
  } catch(e) { showPredictionError('Network error: ' + e.message); }
  finally { setLoading(false); }
}

async function runManualPrediction() {
  const name = getTurbineName(); if (!name) return;
  setLoading(true);
  try {
    const rms  = parseFloat(document.getElementById('sl-rms').value);
    const kurt = parseFloat(document.getElementById('sl-kurt').value);
    const freq = parseFloat(document.getElementById('sl-freq').value);
    const res = await fetch('/api/predict/manual', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({rms, kurtosis: kurt, peak_freq: freq, turbine_name: name})
    });
    const data = await res.json();
    if (data.error) { showPredictionError(data.error); return; }
    renderResult(data, 'Manual Input');
    showToast(`${name} analyzed — ${data.condition}`, data.is_fault ? 'fault' : 'ok');
  } catch(e) { showPredictionError('Network error: ' + e.message); }
  finally { setLoading(false); }
}

function handleCsvUpload(input) {
  if (!input.files[0]) return;
  csvFile = input.files[0];
  const fn = document.getElementById('csv-filename');
  fn.classList.remove('d-none');
  fn.querySelector('span').textContent = csvFile.name;
  document.getElementById('btn-csv-predict').disabled = false;
}

async function runCsvPrediction() {
  const name = getTurbineName(); if (!name) return;
  if (!csvFile) { showPredictionError('Please upload a CSV file first.'); return; }
  setLoading(true);
  try {
    const fd = new FormData();
    fd.append('file', csvFile);
    fd.append('turbine_name', name);
    const res = await fetch('/api/predict/csv', {method:'POST', body: fd});
    const data = await res.json();
    if (data.error) { showPredictionError(data.error); return; }
    renderResult(data, 'CSV Input');
    showToast(`${name} CSV analyzed — ${data.condition}`, data.is_fault ? 'fault' : 'ok');
  } catch(e) { showPredictionError('Network error: ' + e.message); }
  finally { setLoading(false); }
}

function handleDroneUpload(input) {
  if (!input.files[0]) return;
  droneFile = input.files[0];
  const fn = document.getElementById('drone-filename');
  fn.classList.remove('d-none');
  fn.querySelector('span').textContent = droneFile.name;
  document.getElementById('btn-drone-predict').disabled = false;
  const reader = new FileReader();
  reader.onload = e => {
    document.getElementById('drone-preview').src = e.target.result;
    document.getElementById('drone-preview-wrap').classList.remove('d-none');
  };
  reader.readAsDataURL(droneFile);
}

async function runDroneAnalysis() {
  const name = getTurbineName(); if (!name) return;
  if (!droneFile) { showPredictionError('Please upload a drone image first.'); return; }
  setLoading(true);
  try {
    const fd = new FormData();
    fd.append('file', droneFile);
    fd.append('turbine_name', name);
    const res = await fetch('/api/predict/drone-image', {method:'POST', body: fd});
    const data = await res.json();
    if (data.error) { showPredictionError(data.error); return; }
    renderDroneResult(data, name);
    showToast(`${name} drone image analyzed — ${data.label}`, data.score > 70 ? 'fault' : 'ok');
  } catch(e) { showPredictionError('Network error: ' + e.message); }
  finally { setLoading(false); }
}

function renderDroneResult(data, name) {
  document.getElementById('drone-result-box').classList.remove('d-none');
  document.getElementById('drone-res-icon').innerHTML =
    `<i class="fa-solid ${data.icon}" style="color:${data.color}; font-size:2.5rem;"></i>`;
  document.getElementById('drone-res-label').textContent = data.label;
  document.getElementById('drone-res-label').style.color = data.color;
  document.getElementById('drone-res-score').textContent = `Confidence Score: ${data.score}%`;
  document.getElementById('drone-res-detail').textContent = data.detail;
  const bar = document.getElementById('drone-res-bar');
  bar.style.width = data.score + '%';
  bar.style.background = data.color;
  const badge = document.getElementById('drone-res-badge');
  if (data.score > 70) {
    badge.textContent = 'ACTION NEEDED';
    badge.style.cssText = 'background:rgba(239,68,68,0.15);color:#ef4444;border:1px solid rgba(239,68,68,0.4);padding:4px 10px;border-radius:4px;font-size:0.75rem;font-weight:700;';
  } else if (data.score > 50) {
    badge.textContent = 'MONITOR';
    badge.style.cssText = 'background:rgba(234,179,8,0.15);color:#eab308;border:1px solid rgba(234,179,8,0.4);padding:4px 10px;border-radius:4px;font-size:0.75rem;font-weight:700;';
  } else {
    badge.textContent = 'ALL CLEAR';
    badge.style.cssText = 'background:rgba(34,197,94,0.15);color:#22c55e;border:1px solid rgba(34,197,94,0.4);padding:4px 10px;border-radius:4px;font-size:0.75rem;font-weight:700;';
  }

  // Update main result box to show Drone Image source
  const box = document.getElementById('predResultBox');
  box.className = `wg-pred-result-box ${data.score > 70 ? 'fault' : data.score > 50 ? 'warn' : 'healthy'} mb-4`;
  document.getElementById('pred-main-icon').innerHTML =
    `<i class="fa-solid ${data.icon}" style="color:${data.color}"></i>`;
  document.getElementById('pred-badge').textContent = data.score > 70 ? '⚠ FAULT DETECTED' : (data.score > 50 ? '⚡ MONITOR' : '✓ NO DAMAGE');
  document.getElementById('pred-badge').style.color = data.color;
  document.getElementById('pred-class').textContent = data.label;
  document.getElementById('pred-class').style.color = data.color;
  // *** Correct source label ***
  document.getElementById('pred-details').innerHTML =
    `Score: ${data.score}% &nbsp;·&nbsp; <strong style="color:#38bdf8">📡 Drone Image</strong> &nbsp;·&nbsp; ${name} &nbsp;·&nbsp; ${new Date().toLocaleTimeString()}`;

  const ring = document.getElementById('ring-fill');
  ring.setAttribute('stroke-dasharray', `${data.score}, 100`);
  ring.style.stroke = data.color;
  document.getElementById('ring-label').textContent = data.score + '%';

  document.getElementById('pm-box').classList.add('d-none');
  document.getElementById('xai-box').classList.add('d-none');
  document.getElementById('maintenance-box').classList.add('d-none');
  document.getElementById('metrics-row').style.opacity = '0.3';
}

function renderResult(data, inputSource) {
  const src = data.input_source || inputSource || 'Unknown';
  const srcIcons = { 'Manual Input':'🎛️', 'CSV Input':'📄', 'Demo Signal':'🔬', 'Drone Image':'📡' };
  const srcColors= { 'Manual Input':'#a855f7', 'CSV Input':'#22c55e', 'Demo Signal':'#f97316', 'Drone Image':'#38bdf8' };
  const srcIcon  = srcIcons[src]  || '📊';
  const srcColor = srcColors[src] || '#38bdf8';

  const box = document.getElementById('predResultBox');
  const colorMap = {'Healthy':'healthy','Inner Race Fault':'fault','Outer Race Fault':'fault','Ball Fault':'fault','Gear Wear':'warn'};
  box.className = `wg-pred-result-box ${colorMap[data.condition]||'neutral'} mb-4`;

  const iconMap = {'Healthy':'fa-check-circle','Inner Race Fault':'fa-circle-xmark','Outer Race Fault':'fa-circle-xmark','Ball Fault':'fa-circle-xmark','Gear Wear':'fa-gear'};
  document.getElementById('pred-main-icon').innerHTML =
    `<i class="fa-solid ${iconMap[data.condition]||'fa-question'}" style="color:${data.color}"></i>`;
  document.getElementById('pred-badge').textContent = data.is_fault ? '⚠ FAULT DETECTED' : (data.condition === 'Healthy' ? '✓ HEALTHY' : '⚡ WARNING');
  document.getElementById('pred-badge').style.color = data.color;
  document.getElementById('pred-class').textContent = data.condition;
  document.getElementById('pred-class').style.color = data.color;

  // *** SOURCE PILL — clearly shows which input was used ***
  document.getElementById('pred-details').innerHTML =
    `Confidence: <strong>${data.confidence}%</strong>
     &nbsp;·&nbsp;
     <span style="display:inline-flex;align-items:center;gap:4px;padding:2px 10px;border-radius:20px;
       background:${srcColor}22;border:1px solid ${srcColor}55;color:${srcColor};
       font-family:'JetBrains Mono',monospace;font-size:0.78rem;font-weight:700;">
       ${srcIcon} ${src}
     </span>
     &nbsp;·&nbsp; ${turbineName || 'Unnamed'} &nbsp;·&nbsp; ${new Date().toLocaleTimeString()}`;

  const ring = document.getElementById('ring-fill');
  ring.setAttribute('stroke-dasharray', `${data.confidence}, 100`);
  ring.style.stroke = data.color;
  document.getElementById('ring-label').textContent = data.confidence + '%';

  document.getElementById('metrics-row').style.opacity = '1';
  const f = data.features;
  document.getElementById('mc-rms').textContent   = f.rms;
  document.getElementById('mc-kurt').textContent  = f.kurtosis;
  document.getElementById('mc-crest').textContent = f.crest_factor;
  document.getElementById('mc-hf').textContent    = f.hf_energy_ratio;

  const pm = data.predictive_maintenance;
  if (pm) {
    document.getElementById('pm-box').classList.remove('d-none');
    const pmDays = document.getElementById('pm-days');
    pmDays.textContent = pm.estimated_failure_days;
    pmDays.style.color = pm.estimated_failure_days <= 7 ? '#ef4444' : pm.estimated_failure_days <= 21 ? '#eab308' : '#22c55e';
    const pmRec = document.getElementById('pm-rec');
    pmRec.textContent = pm.maintenance_recommended ? '✅ YES' : '✔️ NO';
    pmRec.style.color = pm.maintenance_recommended ? '#eab308' : '#22c55e';
    const urg = document.getElementById('pm-urgency');
    urg.textContent = pm.urgency.toUpperCase();
    urg.style.color = pm.urgency==='critical'?'#ef4444':pm.urgency==='high'?'#f97316':pm.urgency==='medium'?'#eab308':'#22c55e';
  }

  const xai = data.xai_reasons;
  if (xai && xai.length) {
    document.getElementById('xai-box').classList.remove('d-none');
    document.getElementById('xai-reasons-list').innerHTML =
      '<div class="wg-label mb-2">Why this prediction?</div>' +
      xai.map(r => `<div class="wg-xai-reason"><i class="fa-solid fa-circle-dot me-2" style="color:var(--cyan)"></i>${r}</div>`).join('');
  }

  document.getElementById('drone-result-box').classList.add('d-none');

  renderProbaChart(data);
  renderRadarChart(data);
  renderWaveformChart(data);
  renderFftChart(data);
  if (data.rms_trend) renderRmsTrendChart(data);

  if (data.maintenance) {
    document.getElementById('maintenance-box').classList.remove('d-none');
    document.getElementById('maint-text').textContent = data.maintenance;
    document.getElementById('maint-card').style.borderColor = data.color + '55';
  }
}

function renderProbaChart(data) {
  const ctx = document.getElementById('probaChart').getContext('2d');
  if (probaChart) probaChart.destroy();
  probaChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: data.class_names,
      datasets: [{
        data: data.probabilities,
        backgroundColor: ['#22c55e','#ef4444','#f97316','#eab308','#a855f7'].map(c=>c+'aa'),
        borderColor:     ['#22c55e','#ef4444','#f97316','#eab308','#a855f7'],
        borderWidth: 2, borderRadius: 6,
      }]
    },
    options: {
      responsive:true, maintainAspectRatio:false,
      plugins:{legend:{display:false}},
      scales:{
        y:{beginAtZero:true,max:100,grid:{color:'rgba(255,255,255,0.05)'},ticks:{color:'#94a3b8'}},
        x:{grid:{display:false},ticks:{color:'#94a3b8',font:{size:10}}}
      }
    }
  });
}

function renderRadarChart(data) {
  const ctx = document.getElementById('radarChart').getContext('2d');
  if (radarChart) radarChart.destroy();
  const f = data.features;
  const norm = v => Math.min(1, Math.max(0, v));
  radarChart = new Chart(ctx, {
    type:'radar',
    data:{
      labels:['RMS','Kurtosis','Crest','HF Energy','Spec.Ent.','Skewness'],
      datasets:[{
        data:[norm(f.rms/2),norm(f.kurtosis/15),norm(f.crest_factor/10),norm(f.hf_energy_ratio),norm(f.spectral_entropy/12),norm(Math.abs(f.skewness)/3)],
        backgroundColor:data.color+'33', borderColor:data.color, borderWidth:2, pointBackgroundColor:data.color
      }]
    },
    options:{
      responsive:true, maintainAspectRatio:false,
      plugins:{legend:{display:false}},
      scales:{r:{grid:{color:'rgba(255,255,255,0.1)'},ticks:{display:false},pointLabels:{color:'#94a3b8',font:{size:10}}}}
    }
  });
}

function renderWaveformChart(data) {
  const ctx = document.getElementById('waveformChart').getContext('2d');
  if (waveformChart) waveformChart.destroy();
  waveformChart = new Chart(ctx, {
    type:'line',
    data:{
      labels: data.signal.map((_,i)=>i),
      datasets:[{
        label:'Vibration (g)',
        data:data.signal,
        borderColor:data.color, borderWidth:1.5,
        fill:true, backgroundColor:data.color+'18',
        pointRadius:0, tension:0.3
      }]
    },
    options:{
      responsive:true, maintainAspectRatio:false,
      plugins:{legend:{display:false}},
      scales:{
        x:{display:false},
        y:{grid:{color:'rgba(255,255,255,0.05)'},ticks:{color:'#94a3b8',font:{size:9}},
          title:{display:true,text:'Amplitude (g)',color:'#64748b',font:{size:9}}}
      }
    }
  });
}

function renderFftChart(data) {
  const ctx = document.getElementById('fftChart').getContext('2d');
  if (fftChart) fftChart.destroy();
  fftChart = new Chart(ctx, {
    type:'line',
    data:{
      labels: data.fft_freqs.map(f=>f.toFixed(0)),
      datasets:[{
        label:'FFT Amplitude',
        data:data.fft_vals,
        borderColor:'#38bdf8', borderWidth:1.5,
        fill:true, backgroundColor:'#38bdf818',
        pointRadius:0, tension:0.2
      }]
    },
    options:{
      responsive:true, maintainAspectRatio:false,
      plugins:{legend:{display:false}},
      scales:{
        x:{ticks:{color:'#94a3b8',maxTicksLimit:8,font:{size:9}},grid:{color:'rgba(255,255,255,0.04)'},
          title:{display:true,text:'Frequency (Hz)',color:'#64748b',font:{size:9}}},
        y:{grid:{color:'rgba(255,255,255,0.05)'},ticks:{color:'#94a3b8',font:{size:9}}}
      }
    }
  });
}

function renderRmsTrendChart(data) {
  const canvas = document.getElementById('rmsTrendChart');
  if (!canvas) return;
  if (rmsTrendChart) rmsTrendChart.destroy();
  const vals = data.rms_trend;
  rmsTrendChart = new Chart(canvas.getContext('2d'), {
    type:'line',
    data:{
      labels: vals.map((_,i)=>`Seg ${i+1}`),
      datasets:[{
        label:'RMS per Segment (g)',
        data:vals,
        borderColor:'#22c55e', borderWidth:2,
        fill:true, backgroundColor:'#22c55e15',
        pointRadius:3, pointBackgroundColor:'#22c55e',
        tension:0.4
      }]
    },
    options:{
      responsive:true, maintainAspectRatio:false,
      plugins:{legend:{display:false}},
      scales:{
        x:{ticks:{color:'#94a3b8',maxTicksLimit:8,font:{size:9}},grid:{color:'rgba(255,255,255,0.04)'}},
        y:{grid:{color:'rgba(255,255,255,0.05)'},ticks:{color:'#94a3b8',font:{size:9}},
          title:{display:true,text:'RMS (g)',color:'#64748b',font:{size:9}}}
      }
    }
  });
}

function setLoading(on) {
  document.querySelectorAll('.wg-btn-primary').forEach(b => {
    if (on) {
      if (!b.dataset.origHtml) b.dataset.origHtml = b.innerHTML;
      b.disabled = true;
      b.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin me-2"></i>Analyzing…';
    } else {
      b.disabled = false;
      if (b.dataset.origHtml) { b.innerHTML = b.dataset.origHtml; delete b.dataset.origHtml; }
    }
  });
  if (!on) {
    if (csvFile)   document.getElementById('btn-csv-predict').disabled   = false;
    if (droneFile) document.getElementById('btn-drone-predict').disabled  = false;
  }
}

function showPredictionError(msg) {
  const box = document.getElementById('predResultBox');
  box.className = 'wg-pred-result-box fault mb-4';
  document.getElementById('pred-main-icon').innerHTML = '<i class="fa-solid fa-circle-xmark" style="color:#ef4444"></i>';
  document.getElementById('pred-badge').textContent = '⚠ ERROR';
  document.getElementById('pred-badge').style.color = '#ef4444';
  document.getElementById('pred-class').textContent = 'Analysis Failed';
  document.getElementById('pred-class').style.color = '#ef4444';
  document.getElementById('pred-details').textContent = msg;
  showToast(msg, 'fault');
}

function showToast(msg, type) {
  const tc = document.getElementById('toastContainer');
  if (!tc) return;
  const icons = { fault:'fa-circle-xmark', warn:'fa-triangle-exclamation', ok:'fa-check-circle', info:'fa-circle-info' };
  const div = document.createElement('div');
  div.className = `wg-toast ${type}`;
  div.innerHTML = `<i class="fa-solid ${icons[type]||'fa-circle-info'} me-2"></i>${msg}`;
  tc.appendChild(div);
  setTimeout(() => div.remove(), 4500);
}
