/**
 * WindGuard AI — Fixed Live Monitoring JavaScript
 * Fixes:
 * - WebSocket sensor_update listener properly wired
 * - Polling fallback if WebSocket fails
 * - Vibration waveform + FFT charts on monitoring page
 * - Turbine selector works with demo turbines
 * - All charts update in real-time
 */

let selectedTurbine = null;
const rmsHistory  = {};
const kurtHistory = {};
const MAX_POINTS  = 50;

let liveRmsChart  = null;
let liveKurtChart = null;
let liveWaveChart = null;
let liveFftChart  = null;
const sparklines  = {};

let pollingInterval = null;

const THRESHOLDS = {
  rms:             { warn: 0.5,  fault: 0.9 },
  kurtosis:        { warn: 4.5,  fault: 7.0 },
  crest_factor:    { warn: 5.0,  fault: 8.0 },
  hf_energy_ratio: { warn: 0.3,  fault: 0.6 },
  spectral_entropy:{ warn: 9.0,  fault: 11.0, invert: true },
  peak_freq:       { warn: 350,  fault: 450 },
};

// ── Init ──────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // Pick first turbine button as default
  const firstBtn = document.querySelector('.wg-turb-btn');
  if (firstBtn) {
    selectedTurbine = firstBtn.dataset.id;
    firstBtn.classList.add('active');
  }

  liveRmsChart  = initTimeSeries('liveRmsChart',  'RMS Amplitude (g)',  '#00d9f5');
  liveKurtChart = initTimeSeries('liveKurtChart', 'Kurtosis',           '#ef4444');
  liveWaveChart = initWaveformChart();
  liveFftChart  = initFftChart();
  initSparklines();

  if (selectedTurbine) {
    setEl('chart-title-rms',  `${selectedTurbine} — RMS Amplitude (last ${MAX_POINTS} readings)`);
    setEl('chart-title-kurt', `${selectedTurbine} — Kurtosis (last ${MAX_POINTS} readings)`);
  }

  // Start polling as reliable fallback (runs every 2s regardless of WebSocket)
  startPolling();
});

// ── Chart Init ─────────────────────────────────────────────────────────────
function initTimeSeries(canvasId, label, color) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return null;
  return new Chart(ctx, {
    type: 'line',
    data: { labels: [], datasets: [{ label, data: [], borderColor: color,
        backgroundColor: hexToRgba(color, 0.07), borderWidth: 1.5, fill: true,
        tension: 0.4, pointRadius: 0, pointHoverRadius: 5 }] },
    options: {
      animation: { duration: 200 }, responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { color:'#94a3b8', maxTicksLimit: 8, font:{size:9} } },
        y: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color:'#94a3b8', font:{size:9} } }
      }
    }
  });
}

function initWaveformChart() {
  const ctx = document.getElementById('liveWaveformChart');
  if (!ctx) return null;
  return new Chart(ctx, {
    type: 'line',
    data: { labels: [], datasets: [{ label:'Vibration (g)', data: [],
        borderColor: '#00d9f5', backgroundColor: '#00d9f510', borderWidth: 1.5,
        fill: true, tension: 0.3, pointRadius: 0 }] },
    options: {
      animation: false, responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { display: false },
        y: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color:'#94a3b8', font:{size:9} },
          title: { display: true, text: 'Amplitude (g)', color: '#64748b', font:{size:9} } }
      }
    }
  });
}

function initFftChart() {
  const ctx = document.getElementById('liveFftChart');
  if (!ctx) return null;
  return new Chart(ctx, {
    type: 'line',
    data: { labels: [], datasets: [{ label:'FFT Amplitude', data: [],
        borderColor: '#a855f7', backgroundColor: '#a855f710', borderWidth: 1.5,
        fill: true, tension: 0.2, pointRadius: 0 }] },
    options: {
      animation: false, responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { ticks: { color:'#94a3b8', maxTicksLimit:8, font:{size:9} },
          grid: { color:'rgba(255,255,255,0.04)' },
          title: { display:true, text:'Frequency (Hz)', color:'#64748b', font:{size:9} } },
        y: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color:'#94a3b8', font:{size:9} } }
      }
    }
  });
}

function initSparklines() {
  const keys   = ['rms','kurt','crest','freq','hf','entropy'];
  const colors = { rms:'#00d9f5', kurt:'#ef4444', crest:'#eab308', freq:'#00d9f5', hf:'#22c55e', entropy:'#a855f7' };
  keys.forEach(k => {
    const ctx = document.getElementById(`spark-${k}`);
    if (!ctx) return;
    sparklines[k] = new Chart(ctx, {
      type: 'line',
      data: { labels: [], datasets: [{ data: [], borderColor: colors[k], borderWidth: 1.5, fill: false, tension: 0.4, pointRadius: 0 }] },
      options: {
        animation: false, responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display:false }, tooltip: { enabled:false } },
        scales: { x: { display:false }, y: { display:false } }
      }
    });
  });
}

// ── Turbine Selection ─────────────────────────────────────────────────────
function selectTurbine(tid) {
  selectedTurbine = tid;
  document.querySelectorAll('.wg-turb-btn').forEach(b => b.classList.toggle('active', b.dataset.id === tid));
  setEl('chart-title-rms',  `${tid} — RMS Amplitude (last ${MAX_POINTS} readings)`);
  setEl('chart-title-kurt', `${tid} — Kurtosis (last ${MAX_POINTS} readings)`);
  // Reload history for this turbine
  if (liveRmsChart)  { liveRmsChart.data.labels = []; liveRmsChart.data.datasets[0].data = []; liveRmsChart.update('none'); }
  if (liveKurtChart) { liveKurtChart.data.labels = []; liveKurtChart.data.datasets[0].data = []; liveKurtChart.update('none'); }
}

// ── Polling Fallback (always runs, covers WebSocket gaps) ─────────────────
function startPolling() {
  if (pollingInterval) clearInterval(pollingInterval);
  pollingInterval = setInterval(async () => {
    try {
      const res  = await fetch('/api/live-sensor');
      const data = await res.json();
      processReadings(data.ts, data.readings);
    } catch(e) { /* silent */ }
  }, 2000);
  // Immediate first call
  fetch('/api/live-sensor').then(r=>r.json()).then(d=>processReadings(d.ts,d.readings)).catch(()=>{});
}

// ── Socket.IO listener (same processing as polling) ───────────────────────
if (typeof socket !== 'undefined') {
  socket.on('sensor_update', (data) => {
    processReadings(data.ts, data.readings);
  });
}

// ── Core: Process a batch of readings ────────────────────────────────────
function processReadings(ts, readings) {
  if (!readings || !readings.length) return;

  // Update turbine buttons state
  readings.forEach(r => {
    const btn = document.querySelector(`.wg-turb-btn[data-id="${r.turbine_id}"]`);
    if (btn) {
      btn.className = `wg-turb-btn ${r.state}${btn.classList.contains('active') ? ' active' : ''}`;
      const healthEl = btn.querySelector('.wg-turb-btn-health');
      if (healthEl) {
        const h = Math.max(0, Math.min(100, Math.round(100 - r.rms*30 - r.kurtosis*2)));
        healthEl.textContent = h + '%';
      }
    }
  });

  // Update selected turbine data
  if (!selectedTurbine && readings.length > 0) {
    selectedTurbine = readings[0].turbine_id;
  }
  const reading = readings.find(r => r.turbine_id === selectedTurbine) || readings[0];
  if (!reading) return;

  const timeStr = new Date(ts).toLocaleTimeString('en-US',{hour12:false,hour:'2-digit',minute:'2-digit',second:'2-digit'});

  updateSensorCard('rms',     reading.rms,             THRESHOLDS.rms);
  updateSensorCard('kurt',    reading.kurtosis,         THRESHOLDS.kurtosis);
  updateSensorCard('crest',   reading.crest_factor,     THRESHOLDS.crest_factor);
  updateSensorCard('freq',    reading.peak_freq,        THRESHOLDS.peak_freq);
  updateSensorCard('hf',      reading.hf_energy_ratio,  THRESHOLDS.hf_energy_ratio);
  updateSensorCard('entropy', reading.spectral_entropy, THRESHOLDS.spectral_entropy);

  updateFeatureBar('rms',     reading.rms,             2.0);
  updateFeatureBar('kurt',    reading.kurtosis,         15.0);
  updateFeatureBar('crest',   reading.crest_factor,     15.0);
  updateFeatureBar('hf',      reading.hf_energy_ratio,  1.0);
  updateFeatureBar('entropy', reading.spectral_entropy, 12.0);
  updateFeatureBar('freq',    reading.peak_freq,        500.0);

  // RMS Line Chart
  if (liveRmsChart) {
    const chartColor = reading.state==='fault' ? '#ef4444' : reading.state==='warning' ? '#eab308' : '#00d9f5';
    liveRmsChart.data.datasets[0].borderColor = chartColor;
    liveRmsChart.data.datasets[0].backgroundColor = hexToRgba(chartColor, 0.07);
    liveRmsChart.data.labels.push(timeStr);
    liveRmsChart.data.datasets[0].data.push(reading.rms);
    if (liveRmsChart.data.labels.length > MAX_POINTS) { liveRmsChart.data.labels.shift(); liveRmsChart.data.datasets[0].data.shift(); }
    liveRmsChart.update('none');
  }

  // Kurtosis Line Chart
  if (liveKurtChart) {
    liveKurtChart.data.labels.push(timeStr);
    liveKurtChart.data.datasets[0].data.push(reading.kurtosis);
    if (liveKurtChart.data.labels.length > MAX_POINTS) { liveKurtChart.data.labels.shift(); liveKurtChart.data.datasets[0].data.shift(); }
    liveKurtChart.update('none');
  }

  // Live Waveform Chart
  if (liveWaveChart && reading.waveform && reading.waveform.length) {
    const wColor = reading.state==='fault' ? '#ef4444' : reading.state==='warning' ? '#eab308' : '#00d9f5';
    liveWaveChart.data.labels = reading.waveform.map((_,i)=>i);
    liveWaveChart.data.datasets[0].data = reading.waveform;
    liveWaveChart.data.datasets[0].borderColor = wColor;
    liveWaveChart.data.datasets[0].backgroundColor = wColor + '18';
    liveWaveChart.update('none');
  }

  // Live FFT Chart
  if (liveFftChart && reading.fft_vals && reading.fft_vals.length) {
    liveFftChart.data.labels = reading.fft_freqs ? reading.fft_freqs.map(f=>f.toFixed(0)) : reading.fft_vals.map((_,i)=>i);
    liveFftChart.data.datasets[0].data = reading.fft_vals;
    liveFftChart.update('none');
  }

  // Sparklines
  updateSparkline('rms',     reading.rms);
  updateSparkline('kurt',    reading.kurtosis);
  updateSparkline('crest',   reading.crest_factor);
  updateSparkline('freq',    reading.peak_freq);
  updateSparkline('hf',      reading.hf_energy_ratio);
  updateSparkline('entropy', reading.spectral_entropy);

  // Fault alerts
  if (reading.state === 'fault' && Math.random() < 0.04) {
    showToast(`${reading.turbine_id}: Kurtosis ${reading.kurtosis.toFixed(2)} — Fault threshold exceeded`, 'fault', 'FAULT ALERT');
    showAlertBanner(`FAULT: ${reading.turbine_id} — RMS ${reading.rms.toFixed(3)}g, Kurtosis ${reading.kurtosis.toFixed(2)}`);
  }
}

// ── Live Prediction Request ───────────────────────────────────────────────
function requestLivePrediction() {
  if (typeof socket !== 'undefined') {
    socket.emit('request_prediction', { turbine_id: selectedTurbine });
    showToast(`Running ML prediction for ${selectedTurbine}…`, 'info', 'Inference');
  }
}

if (typeof socket !== 'undefined') {
  socket.on('prediction_result', (result) => {
    const box   = document.getElementById('live-pred-box');
    const label = document.getElementById('lp-label');
    const conf  = document.getElementById('lp-conf');
    const bars  = document.getElementById('live-pred-bars');
    if (!box) return;
    box.className = 'wg-pred-box-mini ' + (result.is_fault ? 'fault' : 'healthy');
    if (label) label.textContent = result.condition;
    if (conf)  conf.textContent  = `Confidence: ${result.confidence}%`;
    if (bars && result.class_names) {
      bars.innerHTML = result.class_names.map((name, i) =>
        `<div class="wg-pred-mini-bar-row">
          <div class="wg-pred-mini-bar-label">${name}</div>
          <div class="wg-pred-mini-bar-val">${result.probabilities[i].toFixed(1)}%</div>
        </div>`
      ).join('');
    }
    showToast(`${result.turbine_id}: ${result.condition} (${result.confidence}%)`, result.is_fault ? 'fault' : 'ok', 'ML Prediction');
  });
}

// ── Helpers ───────────────────────────────────────────────────────────────
function updateSensorCard(key, value, threshold) {
  const el   = document.getElementById(`sv-${key}`);
  const card = document.getElementById(`sc-${key}`);
  if (!el || value === undefined) return;
  el.textContent = key === 'freq' ? value.toFixed(1) : value.toFixed(4);
  if (card) card.className = `wg-sensor-card ${getThresholdState(value, threshold)}`;
}

function getThresholdState(val, t) {
  if (!t) return '';
  if (val >= t.fault) return 'fault';
  if (val >= t.warn)  return 'warning';
  return '';
}

function updateFeatureBar(key, value, maxVal) {
  const bar = document.getElementById(`fb-${key}`);
  const val = document.getElementById(`fv-${key}`);
  if (!bar || !val) return;
  bar.style.width = Math.min(100, (Math.abs(value) / maxVal) * 100).toFixed(1) + '%';
  val.textContent = key === 'freq' ? value.toFixed(1) : value.toFixed(4);
}

function updateSparkline(key, value) {
  const spark = sparklines[key];
  if (!spark) return;
  spark.data.labels.push('');
  spark.data.datasets[0].data.push(value);
  if (spark.data.labels.length > 20) { spark.data.labels.shift(); spark.data.datasets[0].data.shift(); }
  spark.update('none');
}

function setEl(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

function hexToRgba(hex, alpha) {
  if (!hex || !hex.startsWith('#')) return `rgba(0,217,245,${alpha})`;
  const r = parseInt(hex.slice(1,3),16);
  const g = parseInt(hex.slice(3,5),16);
  const b = parseInt(hex.slice(5,7),16);
  return `rgba(${r},${g},${b},${alpha})`;
}

function showToast(msg, type) {
  const tc = document.getElementById('toastContainer');
  if (!tc) return;
  const icons = { fault:'fa-circle-xmark', warn:'fa-triangle-exclamation', ok:'fa-check-circle', info:'fa-circle-info' };
  const div = document.createElement('div');
  div.className = `wg-toast ${type}`;
  div.innerHTML = `<i class="fa-solid ${icons[type]||'fa-circle-info'} me-2"></i>${msg}`;
  tc.appendChild(div);
  setTimeout(() => div.remove(), 4000);
}

function showAlertBanner(msg) {
  const b = document.getElementById('alert-banner');
  const t = document.getElementById('alert-banner-text');
  if (b && t) { t.textContent = msg; b.classList.remove('d-none'); setTimeout(() => b.classList.add('d-none'), 8000); }
}
