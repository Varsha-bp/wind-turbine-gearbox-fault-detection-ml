/**
 * WindGuard AI — Fixed Dashboard JS
 * Fixes:
 * - Live fleet chart updates via WebSocket + polling fallback
 * - Turbine grid updates dynamically
 * - All KPI values refresh
 * - Empty state handled cleanly
 */

let fleetRmsChart    = null;
let healthDistChart  = null;
let statusDonutChart = null;
let dynamicTurbines  = [];

document.addEventListener('DOMContentLoaded', () => {
  loadTurbinesAndInit();
  loadAlerts();
});

async function loadTurbinesAndInit() {
  try {
    const res = await fetch('/api/turbines');
    dynamicTurbines = await res.json();
  } catch(e) { dynamicTurbines = []; }

  updateTurbineGrid();
  initFleetRmsChart();
  initHealthDistChart();
  initStatusDonutChart();
}

function updateTurbineGrid() {
  const grid = document.getElementById('turbine-grid');
  if (!grid) return;
  if (!dynamicTurbines.length) {
    grid.innerHTML = `
      <div class="wg-empty-state p-4 text-center w-100">
        <i class="fa-solid fa-wind fa-2x mb-2 text-muted"></i>
        <p class="text-muted mb-1">No turbines registered yet.</p>
        <a href="/prediction" class="wg-btn wg-btn-primary btn-sm mt-2">
          <i class="fa-solid fa-plus me-1"></i>Add Turbine via ML Prediction
        </a>
      </div>`;
    return;
  }
  grid.innerHTML = dynamicTurbines.map(t => `
    <div class="wg-turb-card ${t.state}" data-id="${t.id}">
      <div class="wg-turb-id">${t.id}</div>
      <div class="wg-turb-health ${t.state}">${t.health}%</div>
      <div class="wg-turb-rms mono">${parseFloat(t.rms).toFixed(2)}g</div>
      ${t.state === 'fault'
        ? '<div class="wg-turb-status fault"><i class="fa-solid fa-circle-xmark"></i></div>'
        : t.state === 'warning'
        ? '<div class="wg-turb-status warn"><i class="fa-solid fa-triangle-exclamation"></i></div>'
        : '<div class="wg-turb-status good"><i class="fa-solid fa-check-circle"></i></div>'}
    </div>`).join('');
}

function initFleetRmsChart() {
  const ctx = document.getElementById('fleetRmsChart'); if (!ctx) return;
  const palette = ['#00d9f5','#eab308','#ef4444','#22c55e','#f97316','#a855f7','#38bdf8','#fb923c','#84cc16'];
  if (fleetRmsChart) fleetRmsChart.destroy();
  fleetRmsChart = new Chart(ctx, {
    type:'line',
    data:{
      labels:[],
      datasets: dynamicTurbines.length
        ? dynamicTurbines.map((t,i) => ({
            label:t.id, data:[], borderColor:palette[i%palette.length],
            backgroundColor:'transparent', borderWidth:1.5,
            tension:0.4, pointRadius:0, pointHoverRadius:4
          }))
        : [{label:'Waiting for data…', data:[], borderColor:'#38bdf8', backgroundColor:'transparent',borderWidth:1.5,tension:0.4,pointRadius:0}]
    },
    options:{
      animation:{duration:200}, responsive:true, maintainAspectRatio:false,
      interaction:{mode:'index',intersect:false},
      plugins:{
        legend:{display:dynamicTurbines.length>0,position:'top',labels:{boxWidth:12,padding:12,font:{size:10},color:'#94a3b8'}},
        tooltip:{callbacks:{label:c=>` ${c.dataset.label}: ${c.parsed.y.toFixed(4)} g`}}
      },
      scales:{
        x:{grid:{color:'rgba(255,255,255,0.04)'},ticks:{color:'#94a3b8',maxTicksLimit:8,font:{size:9}}},
        y:{grid:{color:'rgba(255,255,255,0.05)'},ticks:{color:'#94a3b8'},
          title:{display:true,text:'RMS (g)',color:'#64748b',font:{size:10}}}
      }
    }
  });
}

function initHealthDistChart() {
  const ctx = document.getElementById('healthDistChart'); if (!ctx) return;
  if (healthDistChart) healthDistChart.destroy();
  if (!dynamicTurbines.length) {
    healthDistChart = new Chart(ctx, {
      type:'bar',
      data:{labels:['No data'],datasets:[{data:[0],backgroundColor:'#38bdf855',borderRadius:4}]},
      options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},
        scales:{y:{min:0,max:100,ticks:{callback:v=>v+'%',color:'#94a3b8'}},x:{ticks:{color:'#94a3b8'}}}}
    });
    return;
  }
  const colors = dynamicTurbines.map(t => t.state==='fault'?'#ef4444':t.state==='warning'?'#eab308':'#22c55e');
  healthDistChart = new Chart(ctx, {
    type:'bar',
    data:{
      labels:dynamicTurbines.map(t=>t.id),
      datasets:[{label:'Health %',data:dynamicTurbines.map(t=>t.health),
        backgroundColor:colors,borderRadius:4,barPercentage:0.7}]
    },
    options:{
      responsive:true,maintainAspectRatio:false,
      plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>` Health: ${c.parsed.y}%`}}},
      scales:{
        x:{grid:{display:false},ticks:{font:{size:9},color:'#94a3b8'}},
        y:{grid:{color:'rgba(255,255,255,0.05)'},min:0,max:100,ticks:{callback:v=>v+'%',color:'#94a3b8'}}
      }
    }
  });
}

function initStatusDonutChart() {
  const ctx = document.getElementById('statusDonutChart'); if (!ctx) return;
  const faults   = dynamicTurbines.filter(t=>t.state==='fault').length;
  const warnings = dynamicTurbines.filter(t=>t.state==='warning').length;
  const healthy  = dynamicTurbines.filter(t=>t.state==='normal').length;
  if (statusDonutChart) statusDonutChart.destroy();

  const hasData = faults + warnings + healthy > 0;
  statusDonutChart = new Chart(ctx, {
    type:'doughnut',
    data:{
      labels:['Healthy','Warning','Fault'],
      datasets:[{
        data: hasData ? [healthy, warnings, faults] : [1, 0, 0],
        backgroundColor: hasData ? ['#22c55e','#eab308','#ef4444'] : ['#1e3a5f','#1e3a5f','#1e3a5f'],
        borderColor:'#0c1525', borderWidth:3, hoverOffset:4
      }]
    },
    options:{
      responsive:true, maintainAspectRatio:false, cutout:'65%',
      plugins:{
        legend:{position:'bottom',labels:{padding:14,boxWidth:12,font:{size:11},color:'#94a3b8'}},
        tooltip:{callbacks:{label:c=>` ${c.label}: ${c.parsed} turbines`}}
      }
    }
  });
}

async function loadAlerts() {
  const list = document.getElementById('alerts-list'); if (!list) return;
  try {
    const res  = await fetch('/api/alerts');
    const data = await res.json();
    const icons = {fault:'fa-circle-xmark',warning:'fa-triangle-exclamation',info:'fa-circle-info'};
    if (!data.length) {
      list.innerHTML = '<div class="p-3 text-muted text-center">No alerts at this time.</div>';
      return;
    }
    list.innerHTML = data.map(a => `
      <div class="wg-alert-item ${a.type}">
        <i class="fa-solid ${icons[a.type]||'fa-circle-info'} wg-alert-icon"></i>
        <div style="flex:1">
          <div class="wg-alert-title">${a.type.toUpperCase()} — ${a.turbine}</div>
          <div class="wg-alert-desc">${a.message}</div>
        </div>
        <div class="wg-alert-time">${a.ago}</div>
      </div>`).join('');
  } catch(e) {
    list.innerHTML = '<div class="p-3 text-muted">Unable to load alerts.</div>';
  }
}

// Refresh dashboard every 8s
setInterval(async () => {
  await loadTurbinesAndInit();
  await loadAlerts();
  try {
    const res = await fetch('/api/status');
    const d   = await res.json();
    setEl('kpi-total',    d.total_turbines);
    setEl('kpi-faults',   d.fault_count);
    setEl('kpi-warnings', d.warning_count);
    setEl('dash-total',   d.total_turbines);
    const ac = document.getElementById('alert-count');
    if (ac) ac.textContent = d.fault_count + ' critical';
  } catch(e) {}
}, 8000);

function setEl(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

// WebSocket: live fleet RMS chart
if (typeof socket !== 'undefined') {
  socket.on('sensor_update', (data) => {
    if (!fleetRmsChart || !dynamicTurbines.length) return;
    const ts = new Date(data.ts).toLocaleTimeString('en-US',{hour12:false,hour:'2-digit',minute:'2-digit',second:'2-digit'});
    fleetRmsChart.data.labels.push(ts);
    dynamicTurbines.forEach((t, i) => {
      const r = data.readings.find(r => r.turbine_id === t.id);
      if (r && fleetRmsChart.data.datasets[i]) {
        fleetRmsChart.data.datasets[i].data.push(r.rms);
      }
    });
    if (fleetRmsChart.data.labels.length > 40) {
      fleetRmsChart.data.labels.shift();
      fleetRmsChart.data.datasets.forEach(ds => ds.data.shift());
    }
    fleetRmsChart.update('none');
  });
}
